import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('Demo.csv')
print(df)

print(df.mean())
df=df.fillna(df.mean())
print(df)