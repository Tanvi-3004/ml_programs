# Python3 program to show the working of
# randomized PCA

# importing libraries
import numpy as np
from sklearn.decomposition import PCA
from sklearn.utils.extmath import randomized_svd

# dummy data
X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])

# creates instance of PCA with randomized svd_solver
pca = PCA(n_components = 2, svd_solver ='randomized')

# This function takes a matrix and returns the
# U, Sigma and V ^ T elements
U, S, VT = randomized_svd(X, n_components = 2)

# matrix returned by randomized_svd
print(f"Matrix U of size m * m: {U}\n")
print(f"Matrix S of size m * n: {S}\n")
print(f"Matrix V ^ T of size n * n: {VT}\n")

# fitting the pca model
pca.fit(X)

# printing the explained variance ratio
print("Explained Variance using PCA with randomized svd_solver:", pca.explained_variance_ratio_)
